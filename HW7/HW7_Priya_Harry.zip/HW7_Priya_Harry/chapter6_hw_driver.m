%% Chapter 6 Homework Driver Script
% Priya Harry, ENGR R148
clear;
clc;
close all;

%% Problem 6.1: ASTM Grain Count
disp('--- Problem 6.1: ASTM Grain Count ---');
n_values = 10:100;
N_values = num_grains(n_values);

% Display a few results to the command window
disp('Grain sizes (n) from 10 to 15 and their corresponding N values:');
disp(table(n_values(1:6)', N_values(1:6)', 'VariableNames', {'ASTM_Size_n', 'Num_Grains_N'}));

% Create plot for Problem 6.1
figure('Name', 'Problem 6.1: ASTM Grain Size');
plot(n_values, N_values, 'LineWidth', 1.5);
grid on;
xlabel('ASTM Grain Size (n)');
ylabel('Number of Grains per Square Inch (N)');
title('Number of Grains vs. ASTM Grain Size');

%% Problem 6.2: Mass and Energy
disp('--- Problem 6.2: Mass and Energy ---');
% Create mass vector from 1 kg to 10^6 kg using logspace
mass_vector = logspace(0, 6, 100); 
energy_vector = energy(mass_vector);

% Find energy for specific endpoints
fprintf('Energy for 1 kg = %.4e J\n', energy(1));
fprintf('Energy for 10^6 kg = %.4e J\n', energy(1e6));

% Create plots using different logarithmic approaches as requested
figure('Name', 'Problem 6.2: Mass and Energy Plots');

subplot(2, 2, 1);
plot(mass_vector, energy_vector);
title('Standard Plot');
xlabel('Mass (kg)'); ylabel('Energy (J)');
grid on;

subplot(2, 2, 2);
semilogy(mass_vector, energy_vector);
title('semilogy Plot');
xlabel('Mass (kg)'); ylabel('Energy (J)');
grid on;

subplot(2, 2, 3);
semilogx(mass_vector, energy_vector);
title('semilogx Plot');
xlabel('Mass (kg)'); ylabel('Energy (J)');
grid on;

subplot(2, 2, 4);
loglog(mass_vector, energy_vector);
title('loglog Plot (Best Approach)');
xlabel('Mass (kg)'); ylabel('Energy (J)');
grid on;

%% Problem 6.3: Future Value
disp('--- Problem 6.3: Future Value ---');
PV = 1000;              % Initial investment in dollars
annual_rate = 0.005;    % 0.5% per month
years = 10;
compounding_periods = years * 12; % Monthly compounding for 10 years

FV_result = future_value(PV, annual_rate, compounding_periods);

fprintf('Initial Investment: $%.2f\n', PV);
fprintf('Interest Rate: %.1f%% per month\n', annual_rate * 100);
fprintf('Time Period: %d years (%d compounding periods)\n', years, compounding_periods);
fprintf('Future Value: $%.2f\n', FV_result);