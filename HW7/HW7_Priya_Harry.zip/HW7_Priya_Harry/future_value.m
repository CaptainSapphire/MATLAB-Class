function FV = future_value(PV, I, N)
% FUTURE_VALUE Calculates the future value of an investment.
% Inputs:
%   PV - Present value or initial investment amount
%   I  - Interest rate per compounding period expressed as a fraction
%   N  - Number of compounding periods
% Outputs:
%   FV - Future value of the investment

FV = PV .* (1 + I).^N;
end