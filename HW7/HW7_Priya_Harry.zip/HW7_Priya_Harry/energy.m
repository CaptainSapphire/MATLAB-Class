function E = energy(m)
% ENERGY Calculates the energy corresponding to a given mass using E = mc^2.
% Inputs: m - Mass in kilograms (scalar or vector)
% Outputs: E - Energy in joules (kg m^2 / s^2)

    c = 2.9979e8; % Speed of light in a vacuum in m/s
    E = m .* (c.^2);
end