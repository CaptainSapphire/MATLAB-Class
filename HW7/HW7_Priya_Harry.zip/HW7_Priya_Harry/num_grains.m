function N = num_grains(n)
    % NUM_GRAINS Calculates the number of grains in a 1-square-inch area (N) at 100x magnification given the ASTM grain size (n).
    % Inputs: n - ASTM grain size (scalar or vector)
    % Outputs: N - Number of grains per square inch
    N = 2.^(n - 1);
end